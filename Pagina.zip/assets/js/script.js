// Simulación de datos de foros
let foros = [];

// Evento al cargar la página
window.addEventListener("load", () => {
    mostrarForos();
});

// Función para mostrar los foros del usuario
function mostrarForos() {
    const forosDiv = document.getElementById("foros");
    forosDiv.innerHTML = "<h2>Tus Foros</h2>";
    for (const foro of foros) {
        if (foro.correo === localStorage.getItem("correo")) {
            const foroElement = document.createElement("div");
            foroElement.innerHTML = `
                <h3>${foro.titulo}</h3>
                <p>${foro.descripcion}</p>
            `;
            forosDiv.appendChild(foroElement);
        }
    }
}

// Función para crear un nuevo foro
document.getElementById("crear-foro").addEventListener("submit", (event) => {
    event.preventDefault();
    const correo = document.getElementById("correo").value;
    const titulo = document.getElementById("titulo").value;
    const descripcion = document.getElementById("descripcion").value;
    const foro = { correo, titulo, descripcion };
    foros.push(foro);
    mostrarForos();
});

// Almacenar el correo del usuario en el almacenamiento local
localStorage.setItem("correo", "correo@example.com"); // Aquí deberías obtener el correo del usuario desde la autenticación
