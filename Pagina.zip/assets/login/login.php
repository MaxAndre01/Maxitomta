<?php
session_start();
error_reporting(0);
include("dbconnection.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['userEmail'];
    $password = $_POST['userPassword'];
    
    // Escapar variables para prevenir inyecciones SQL
    $email = mysqli_real_escape_string($con, $email);
    $password = mysqli_real_escape_string($con, $password);
    
    // Consulta para verificar las credenciales del usuario
    $query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($con, $query);
    
    // Verificar si se encontró un usuario con las credenciales proporcionadas
    if (mysqli_num_rows($result) == 1) {
        // Iniciar sesión y redirigir al usuario a la página de inicio
        $_SESSION['user_email'] = $email;
        header('Location: index.html');
        exit;
    } else {
        // Si las credenciales son incorrectas, mostrar un mensaje de error
        echo "<script>alert('Credenciales incorrectas. Por favor, intenta de nuevo.');</script>";
        echo "<script>window.location.href='login.html'</script>";
    }
}
?>
