<?php
session_start();
error_reporting(0);
include("dbconnection.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $mobile = $_POST['phone'];
  $gender = $_POST['gender'];
  $query = mysqli_query($con, "select email from user where email='$email'");
  $num = mysqli_fetch_array($query);
  if ($num > 1) {
    echo "<script>alert('Correo electrónico ya registrado con nosotros. Intente con una identificación de correo electrónico diferente.');</script>";
    echo "<script>window.location.href='registration.php'</script>";
  } else {
    mysqli_query($con, "insert into user(name,email,password,mobile,gender) values('$name','$email','$password','$mobile','$gender')");
    echo "<script>alert('Tu cuenta ha sido creada correctamente');</script>";
    echo "<script>window.location.href='login.php'</script>";
  }
}
?>