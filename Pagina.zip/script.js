document.addEventListener("DOMContentLoaded", function() {
    const commentForm = document.getElementById('commentForm');
    const usernameInput = document.getElementById('usernameInput');
    const commentInput = document.getElementById('commentInput');
    const commentsContainer = document.getElementById('commentsContainer');

    commentForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const username = usernameInput.value.trim();
        const commentText = commentInput.value.trim();
        if (username !== '' && commentText !== '') {
            addComment(username, commentText);
            usernameInput.value = '';
            commentInput.value = '';
        }
    });

    function addComment(username, commentText) {
        const commentElement = document.createElement('div');
        commentElement.classList.add('comment');
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Eliminar';
        deleteButton.classList.add('delete-btn');
        deleteButton.addEventListener('click', function() {
            commentElement.remove();
        });
        const commentContent = document.createElement('p');
        commentContent.textContent = username + ': ' + commentText;
        commentElement.appendChild(commentContent);
        commentElement.appendChild(deleteButton);
        commentsContainer.appendChild(commentElement);
    }
});

